<!DOCTYPE html>
<html>
<head>
  <title>CREATIONS</title>
  <link href="./css/style.css" rel="stylesheet">
  
  <style>
  h1 {text-align: center;}
  
  h2 {text-align: center;}
  
  body {font-family: Courier, Impact;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

.psw {
  float: right;
  padding-top: 16px;
}
</style>
<style>
  ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}

/* Change the link color on hover */
li a:hover {
  background-color: #555;
  color: white;
}
</style>
</head>
<body style="color: white;">
  <?php include './inc/navbar.php' ?>
  <?php include './inc/login.php' ?> 
  <?php include './inc/gradient.php' ?>
  
  <div class= "shoppingcart.php">
    <a href="./shoppingcart.php">
        <img class="shoppingcart" border="0" src="./images/shoppingcart.png" alt="BAT Cart" width="50" height="50">
    </a>  
  </div>
 
 <h1>NEW WILD CREATIONS</h1>
 <h2>We're Going To Peek Into You All's Imagination With These Brand New Creations</h2>
  <h3>Do You Want This One?</h3>
  <div display="inline-block">  
   <p>This animal has muted turquoise skin and a body shaped like a sparrow's.</p>
   <p>Its face resembles that of an alligator and its eyes remind you of a porcupine's.</p>
   <p>It has horse-like hooves and a long mane around its neck.</p>
<button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact;"><a href="thanks.php">WANT IT!</a></button>
  </div>
  <br>
  
  <h3>Do You Want This One?</h3>
  <div display="inline-block"> 
   <p>This animal is covered in drab green scales and has a body shaped like a gorilla's.</p> 
   <p>Its face resembles that of an alligator and its eyes remind you of a porcupine's.</p> 
   <p>It has a frill around its neck, a pair of bat-like wings, and spines on its back.</p>
<button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact;"><a href="thanks.php">WANT IT!</a></button>
  </div>
  <br>

  <h3>Do You Want This One?</h3>
   <p>This animal has vivid pink skin and a body shaped like a snake's.</p>
   <p>Its face resembles that of a turkey and its eyes remind you of a monitor</p>
   <p>lizard's. It has clawed feet and a pair of bat-like wings.</p>
<button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact;"><a href="thanks.php">WANT IT!</a></button>

  <h3>Do You Want This One?</h3>
   <p>This animal has mid-length light gray fur and has a body shaped like a crow's.</p>
   <p>Its face resembles that of a crane and its eyes remind you of a deer's. It has a</p> 
   <p>frill around its neck and spines on its back.</p>
<button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact;"><a href="thanks.php">WANT IT!</a></button>

  <h3>Do You Want This One?</h3>
   <p>This animal has short dark purplish gray fur and has a body shaped like a gorilla's.</p>
   <p>Its face resembles that of a gecko and its eyes remind you of a gecko's.</p> 
   <p>It has cloven hooves, a mid-length mane around its neck, and a sail fin on its back.</p>
<button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact;"><a href="thanks.php">WANT IT!</a></button>
</body>
</html>
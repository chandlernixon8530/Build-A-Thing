<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #8F4714;
}

li a {
  display: block;
  color: white;
  padding: 8px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #D27533;
  color: white;
}
</style>
    
</head>
<body style="color: white;">
    <div class="BATlogo">
      <a class="active" href="./index.php"><img class="logo" src="./images/logo.png" alt="Build-a-Thing" width="160" height="140"></a>
    </div>

    <div class="navbar">
         <ul>
            <li><a href="./animals.php">ANIMALS</a></li>
            <li><a href="./creations.php">CREATIONS</a></li>
            <li><a href="./clothes.php">CLOTHES</a></li>
         </ul>
    </div>
    
</body>
</html>


  
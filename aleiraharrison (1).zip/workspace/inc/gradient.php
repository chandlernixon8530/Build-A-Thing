<!DOCTYPE>
<html>
<head>
<style>
#grad1 {
  height: 200px;
  background-image: linear-gradient(to right, rgba(225,163,119), rgba(205,102,29), rgba(142,27,27)); 
}

html {
    height: 100%;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    background: #70bg32;
    background-repeat:no-repeat;
    background: -webkit-linear-gradient(to right, rgba(225,163,119), rgba(205,102,29), rgba(142,27,27));
    background: -moz-linear-gradient(to right, rgba(225,163,119), rgba(205,102,29), rgba(142,27,27));
    background: -ms-linear-gradient(to right, rgba(225,163,119), rgba(205,102,29), rgba(142,27,27));
    background: -o-linear-gradient(to right, rgba(225,163,119), rgba(205,102,29), rgba(142,27,27));
    background: linear-gradient(to right, rgba(225,163,119), rgba(205,102,29), rgba(142,27,27));
}
</style>
</head>
</head>
<body>
<div id="grad1"></div>
</body>
</html>
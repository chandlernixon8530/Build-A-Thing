<!DOCTYPE html>
<html>
<head>
  <title>ANIMALS</title>
  <link href="./css/style.css" rel="stylesheet">
  
<style>
  body {font-family: Courier, Impact;}
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

.psw {
  float: right;
  padding-top: 16px;
}

.row {
  display: flex;
}

/* Create two equal columns that sits next to each other */
.column {
  flex: 50%;
  padding: 10px;
}

</style>
</head>
<body  >
<?php include './inc/navbar.php' ?>
<?php include './inc/login.php' ?> 
<?php include './inc/gradient.php' ?>

  <div class="shoppingcart.php">
    <a href="./shoppingcart.php">
        <img class="shoppingcart" border="0" src="./images/shoppingcart.png" alt="BAT Cart" width="50" height="50">
    </a>  
  </div>
  
    <h1 style="color:white; text-align:center;">ANY ANIMAL YOU COULD THINK OF!</h1>
    
<div class="row">
  <div class="column">
    <div id="textbox" display="inline-block">  
    <img src="./images/cutie.png" width="270" height="275">
      <p>This rare species is a duckling and turtle breed,</p>
      <p>but the cutest crossover breed we have.</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
    
    <div display="inline-block">
    <img src="./images/dirds.png" width="270" height="275">
      <p>This breed is a cross of a little dog and a common</p>
      <p>bird. This breed is a simple, but intriguing choice.</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
    
    <div display="inline-block">
    <img src="./images/elshark.png" width="270" height="275">
      <p>This combination is quite interesting because you</p>
      <p>have to have a very large pool to house this breed,</p>but who doesn't like sharks and the Deltas signature anthem!</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
    
    <div display="inline-block">
    <img src="./images/pandger.png" width="270" height="275">
      <p>This mixture of breeds are very different because</p>
      <p>you have the sweetness of the panda, but, then you</p>
      <p>have the aggressivenes of the tiger when aggravated.</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
  </div>
    
  <div class="column">
    <div display="inline-block">
    <img src="./images/penguin.png" width="270" height="275">
      <p>his design of breeds was very hard to put together</p>
      <p>because you have the penguin who is cold by nature,</p>
      <p>then you have the pug dog that loves being warm.</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
    
    <div display="inline-block">
    <img src="./images/rhinoshark.png" width="270" height="275">
      <p>This cross in genetics just might be the most</p>
      <p>dangerous make up yet. With the rhino being an</p>
      <p>air breather and the fish being an emphibian</p>
      <p>this breed will definitely keep you on your toes!</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
    
    <div display="inline-block">
    <img src="./images/tree.png" width="270" height="275">
      <p>This jumble of specimens are very...different</p>
      <p>because we don't think that, normally, an owl</p>
      <p>and a racoon would even be a possible match up,</p>
      <p>but that's what we do here. Beat The Odds!</p>
    <button type="button" class="btn btn-outline-primary" style="font-family: Courier, Impact; width:150px; text-align:center; vertical-align:middle; padding: 25px;"><a href="shoppingcart.php">WANT IT!</a></button>
    </div>
    
  </div>
</div>
</body>
</html>
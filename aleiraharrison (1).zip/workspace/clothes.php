<!DOCTYPE html>
<html>
<head>
    <title>CLOTHES</title>
    <link href="./css/style.css" rel="stylesheet"> 
    
<style>

  body {font-family: Courier, Impact;}
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>
<?php include './inc/navbar.php' ?>
<?php include './inc/login.php' ?> 
<?php include './inc/gradient.php' ?>

  <div class= "shoppingcart.php">
    <a href="./shoppingcart.php">
        <img class="shoppingcart" border="0" src="./images/shoppingcart.png" alt="BAT Cart" width="50" height="50">
    </a>  
  </div>
<h1>GET TO BUYIN'</h1>

<div class="row">
 <div class="column"> 
 <h2 style="text-indent:140px;">TO COOL FOR SCHOOL</h2> 
  <img src="./images/cool.png.png" style="width:30%">
  
 <h2>WARMMY</h2> 
  <img src="./images/cozy.png.jpg" style="width:30%">
  
 <h2>COZY</h2> 
  <img src="./images/fur.png" style="width:30%">
  
 <h2>SWAGGY</h2> 
  <img src="./images/hoodie.png" style="width:30%">
 </div> 
 
 <div class="column">
 <h2>DANGER</h2> 
  <img src="./images/yellow.png" style="width:30%">
  
 <h2>SMOOVE GUY</h2> 
  <img src="./images/winter.png" style="width:30%">
  
 <h2>COMFY</h2> 
  <img src="./images/blanket.png" style="width:30%">
  
 <h2>POLKA FOR DAYS</h2> 
  <img src="./images/polka.png" style="width:30%">
  
 </div> 
</div>  
</body>
</html>
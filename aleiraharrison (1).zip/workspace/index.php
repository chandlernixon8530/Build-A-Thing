<!DOCTYPE html>
<html>
<html lang="en">    
<head>
    
    <title>BUILD-A-THING</title>

    <!-- Bootstrap Core CSS -->
    <link href=".css/bootstrap.css" rel="stylesheet">

    <!--Custom CSS -->
    <link href="./css/style.css" rel="stylesheet">
    
    <!-- Custom Fonts -->
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
<style>
body {
  font-family: Courier, Impact;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}
.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

.psw {
  float: right;
  padding-top: 16px;
}

.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
  text-align: center;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
  text-align: center;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
  text-align: center;
}

.fa-instagram {
  background: #125688;
  color: white;
  text-align: center;
}
</style>
</head>
<body style="color: white;">
<?php include './inc/navbar.php' ?>
<?php include './inc/login.php' ?>
<?php include './inc/gradient.php' ?>
  <div class= "shoppingcart.php">
    <a href="./shoppingcart.php">
        <img class="shoppingcart" border="0" src="./images/shoppingcart.png" alt="BAT Cart" width="50" height="50" style="position:right;">
    </a>  
  </div>
<center>
  
  <h1>
    <font color="white" position="center">BUILD-A-THING</font>
  </h1>
  
  <div class="slideshow-container">

  <div class="mySlides fade">
    <img src="./images/penguin.png" style="width:30%">
  </div>

  <div class="mySlides fade">
    <img src="./images/dirds.png" style="width:70%">
  </div>

  <div class="mySlides fade">
    <img src="./images/tree.png" style="width:50%">
  </div>

  <div class="mySlides fade">
    <img src="./images/elshark.png" style="width:63%">
  </div>

  <div class="mySlides fade">
    <img src="./images/rhinoshark.png" style="width:52%">
  </div>

  <div class="mySlides fade">
    <img src="./images/pandger.png" style="width:45%">
  </div>

  </div>
</center>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 7 seconds
}
</script>

<h2>CONNECT WITH US!</h2>
  <!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-linkedin"></a>
<a href="#" class="fa fa-instagram"></a>

</body>
</html>

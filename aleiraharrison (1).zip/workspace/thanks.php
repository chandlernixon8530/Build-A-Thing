<!DOCTYPE html>
<html>
  <head>
    <title>FEEDBACK</title>
  </head>
    <style>
title {
  text-align: center;  
}
        
body {
  text-align: center;
  background-image: center;
}
        
.fa {
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
  opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
  text-align: center;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
  text-align: center;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
  text-align: center;
}

.fa-instagram {
  background: #125688;
  color: white;
  text-align: center;
}
</style>
    <body>
     <img src="./images/eagle.png" style="width:75%">
        <h1>THANK YOU FOR YOUR FEEDBACK!</h1>
        
    <h2>Please Feel Free To Contact Us On Our Social Medias!</h2>
         <!-- Add font awesome icons -->
        <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-linkedin"></a>
        <a href="#" class="fa fa-instagram"></a>
        
    </body>
</html>